export const CLOUDINARY = 'Cloudinary';
