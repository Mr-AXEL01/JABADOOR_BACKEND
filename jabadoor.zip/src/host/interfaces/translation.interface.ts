export interface Translation {
    nom: string;
    About?: string;
  }
  