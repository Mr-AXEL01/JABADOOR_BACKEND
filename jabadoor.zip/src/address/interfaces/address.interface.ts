
export interface AddressDetails {
  address: string;
  city: string;
  country: string;
}
